package challenger

import (
	"context"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/lightningnetwork/lnd/lnrpc"
	"github.com/lightningnetwork/lnd/lntypes"
	"github.com/lightningnetwork/lnd/queue"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
)

var (
	defaultTimeout = 100 * time.Millisecond
)

type invoiceStreamMock struct {
	lnrpc.Lightning_SubscribeInvoicesClient

	updateChan chan *lnrpc.Invoice
	errChan    chan error
	quit       chan struct{}
}

func (i *invoiceStreamMock) Recv() (*lnrpc.Invoice, error) {
	select {
	case msg := <-i.updateChan:
		return msg, nil

	case err := <-i.errChan:
		return nil, err

	case <-i.quit:
		return nil, context.Canceled
	}
}

type mockInvoiceClient struct {
	invoices   []*lnrpc.Invoice
	updateChan chan *lnrpc.Invoice
	errChan    chan error
	quit       chan struct{}

	lastAddIndex uint64
}

// ListInvoices returns a paginated list of all invoices known to lnd.
func (m *mockInvoiceClient) ListInvoices(_ context.Context,
	r *lnrpc.ListInvoiceRequest,
	_ ...grpc.CallOption) (*lnrpc.ListInvoiceResponse, error) {

	if r.IndexOffset >= uint64(len(m.invoices)) {
		return &lnrpc.ListInvoiceResponse{}, nil
	}

	endIndex := r.IndexOffset + r.NumMaxInvoices
	if endIndex > uint64(len(m.invoices)) {
		endIndex = uint64(len(m.invoices))
	}

	return &lnrpc.ListInvoiceResponse{
		Invoices:        m.invoices[r.IndexOffset:endIndex],
		LastIndexOffset: endIndex,
	}, nil
}

// SubscribeInvoices subscribes to updates on invoices.
func (m *mockInvoiceClient) SubscribeInvoices(_ context.Context,
	in *lnrpc.InvoiceSubscription, _ ...grpc.CallOption) (
	lnrpc.Lightning_SubscribeInvoicesClient, error) {

	m.lastAddIndex = in.AddIndex

	return &invoiceStreamMock{
		updateChan: m.updateChan,
		errChan:    m.errChan,
		quit:       m.quit,
	}, nil
}

// AddInvoice adds a new invoice to lnd.
func (m *mockInvoiceClient) AddInvoice(_ context.Context, in *lnrpc.Invoice,
	_ ...grpc.CallOption) (*lnrpc.AddInvoiceResponse, error) {

	m.invoices = append(m.invoices, in)

	return &lnrpc.AddInvoiceResponse{
		RHash:          in.RHash,
		PaymentRequest: in.PaymentRequest,
		AddIndex:       uint64(len(m.invoices) - 1),
	}, nil
}

func (m *mockInvoiceClient) stop() {
	close(m.quit)
}

func newChallenger() (*LndChallenger, *mockInvoiceClient, chan error) {
	mockClient := &mockInvoiceClient{
		updateChan: make(chan *lnrpc.Invoice),
		errChan:    make(chan error, 1),
		quit:       make(chan struct{}),
	}
	genInvoiceReq := func(price int64) (*lnrpc.Invoice, error) {
		return newInvoice(lntypes.ZeroHash, 99, lnrpc.Invoice_OPEN),
			nil
	}
	invoicesMtx := &sync.Mutex{}
	mainErrChan := make(chan error)
	return &LndChallenger{
		client:        mockClient,
		batchSize:     1,
		clientCtx:     context.Background,
		genInvoiceReq: genInvoiceReq,
		invoiceStates: make(map[lntypes.Hash]lnrpc.Invoice_InvoiceState),
		quit:          make(chan struct{}),
		invoicesMtx:   invoicesMtx,
		invoicesCond:  sync.NewCond(invoicesMtx),
		errChan:       mainErrChan,
		strictVerify:  true,
	}, mockClient, mainErrChan
}

func newInvoice(hash lntypes.Hash, addIndex uint64,
	state lnrpc.Invoice_InvoiceState) *lnrpc.Invoice {

	return &lnrpc.Invoice{
		PaymentRequest: "foo",
		RHash:          hash[:],
		AddIndex:       addIndex,
		State:          state,
		CreationDate:   time.Now().Unix(),
		Expiry:         10,
	}
}

func newSettlementQueue() *queue.ConcurrentQueue {
	q := queue.NewConcurrentQueue(100)
	q.Start()
	return q
}

func TestLndChallenger(t *testing.T) {
	t.Parallel()

	// First of all, test that the NewLndChallenger doesn't allow a nil
	// invoice generator function.
	errChan := make(chan error)
	_, err := NewLndChallenger(nil, 1, nil, nil, errChan, true)
	require.Error(t, err)

	// Now mock the lnd backend and create a challenger instance that we can
	// test.
	c, invoiceMock, mainErrChan := newChallenger()

	// Creating a new challenge should add an invoice to the lnd backend.
	req, hash, err := c.NewChallenge(1337)
	require.NoError(t, err)
	require.Equal(t, "foo", req)
	require.Equal(t, lntypes.ZeroHash, hash)
	require.Equal(t, 1, len(invoiceMock.invoices))
	require.Equal(t, uint64(0), invoiceMock.lastAddIndex)

	// Now we already have an invoice in our lnd mock. When starting the
	// challenger, we should have that invoice in the cache and a
	// subscription that only starts at our faked addIndex.
	err = c.Start()
	require.NoError(t, err)
	require.Equal(t, 1, len(c.invoiceStates))
	require.Equal(t, lnrpc.Invoice_OPEN, c.invoiceStates[lntypes.ZeroHash])
	require.Equal(t, uint64(99), invoiceMock.lastAddIndex)
	require.NoError(t, c.VerifyInvoiceStatus(
		lntypes.ZeroHash, lnrpc.Invoice_OPEN, defaultTimeout,
	))
	require.Error(t, c.VerifyInvoiceStatus(
		lntypes.ZeroHash, lnrpc.Invoice_SETTLED, defaultTimeout,
	))

	// Next, let's send an update for a new invoice and make sure it's added
	// to the map.
	hash = lntypes.Hash{77, 88, 99}
	invoiceMock.updateChan <- newInvoice(hash, 123, lnrpc.Invoice_SETTLED)
	require.NoError(t, c.VerifyInvoiceStatus(
		hash, lnrpc.Invoice_SETTLED, defaultTimeout,
	))
	require.Error(t, c.VerifyInvoiceStatus(
		hash, lnrpc.Invoice_OPEN, defaultTimeout,
	))

	// Finally, create a bunch of invoices but only settle the first 5 of
	// them. All others should get a failed invoice state after the timeout.
	var (
		numInvoices = 20
		errors      = make([]error, numInvoices)
		wg          sync.WaitGroup
	)
	for i := 0; i < numInvoices; i++ {
		hash := lntypes.Hash{77, 88, 99, byte(i)}
		invoiceMock.updateChan <- newInvoice(
			hash, 1000+uint64(i), lnrpc.Invoice_OPEN,
		)

		// The verification will block for a certain time. But we want
		// all checks to happen automatically to simulate many parallel
		// requests. So we spawn a goroutine for each invoice check.
		wg.Add(1)
		go func(errIdx int, hash lntypes.Hash) {
			defer wg.Done()

			errors[errIdx] = c.VerifyInvoiceStatus(
				hash, lnrpc.Invoice_SETTLED, defaultTimeout,
			)
		}(i, hash)
	}

	// With all 20 goroutines spinning and waiting for updates, we settle
	// the first 5 invoices.
	for i := 0; i < 5; i++ {
		hash := lntypes.Hash{77, 88, 99, byte(i)}
		invoiceMock.updateChan <- newInvoice(
			hash, 1000+uint64(i), lnrpc.Invoice_SETTLED,
		)
	}

	// Now wait for all checks to finish, then check that the last 15
	// invoices timed out.
	wg.Wait()
	for i := 0; i < numInvoices; i++ {
		if i < 5 {
			require.NoError(t, errors[i])
		} else {
			require.Error(t, errors[i])
			require.Contains(
				t, errors[i].Error(),
				"invoice status not correct before timeout",
			)
		}
	}

	// Finally test that if an error occurs in the invoice subscription the
	// challenger reports it on the main error channel to cause a shutdown
	// of aperture. The mock's error channel is buffered so we can send
	// directly.
	invoiceMock.errChan <- fmt.Errorf("an expected error")
	select {
	case err := <-mainErrChan:
		require.Error(t, err)

		// Make sure that the goroutine exited.
		done := make(chan struct{})
		go func() {
			c.wg.Wait()
			done <- struct{}{}
		}()

		select {
		case <-done:

		case <-time.After(defaultTimeout):
			t.Fatalf("wait group didn't finish before timeout")
		}

	case <-time.After(defaultTimeout):
		t.Fatalf("error not received on main chan before the timeout")
	}

	invoiceMock.stop()
	c.Stop()
}

func TestSettlementQueue(t *testing.T) {
	t.Parallel()

	var (
		mu      sync.Mutex
		settled []lntypes.Hash
	)

	mockClient := &mockInvoiceClient{
		updateChan: make(chan *lnrpc.Invoice),
		errChan:    make(chan error, 1),
		quit:       make(chan struct{}),
	}
	genInvoiceReq := func(price int64) (*lnrpc.Invoice, error) {
		return newInvoice(lntypes.ZeroHash, 99, lnrpc.Invoice_OPEN),
			nil
	}
	invoicesMtx := &sync.Mutex{}
	c := &LndChallenger{
		client:        mockClient,
		batchSize:     1,
		clientCtx:     context.Background,
		genInvoiceReq: genInvoiceReq,
		invoiceStates: make(
			map[lntypes.Hash]lnrpc.Invoice_InvoiceState,
		),
		quit:         make(chan struct{}),
		invoicesMtx:  invoicesMtx,
		invoicesCond: sync.NewCond(invoicesMtx),
		errChan:      make(chan error),
		strictVerify: false,
		onSettled: func(hash lntypes.Hash) {
			mu.Lock()
			settled = append(settled, hash)
			mu.Unlock()
		},
		settlementQueue: newSettlementQueue(),
	}

	err := c.Start()
	require.NoError(t, err)

	// Send 5 settlement updates.
	numSettlements := 5
	for i := 0; i < numSettlements; i++ {
		hash := lntypes.Hash{byte(i)}
		mockClient.updateChan <- newInvoice(
			hash, uint64(i), lnrpc.Invoice_SETTLED,
		)
	}

	// Wait for all to be processed.
	require.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return len(settled) == numSettlements
	}, time.Second, 10*time.Millisecond)

	// Verify all hashes were received.
	mu.Lock()
	require.Len(t, settled, numSettlements)
	mu.Unlock()

	mockClient.stop()
	c.Stop()
}

func TestSettlementReconcilesHistoricalInvoicesOnStart(t *testing.T) {
	t.Parallel()

	var (
		mu      sync.Mutex
		settled []lntypes.Hash
	)

	hash := lntypes.Hash{9, 9, 9}
	mockClient := &mockInvoiceClient{
		invoices: []*lnrpc.Invoice{
			newInvoice(hash, 77, lnrpc.Invoice_SETTLED),
		},
		updateChan: make(chan *lnrpc.Invoice),
		errChan:    make(chan error, 1),
		quit:       make(chan struct{}),
	}
	invoicesMtx := &sync.Mutex{}
	c := &LndChallenger{
		client:    mockClient,
		batchSize: 10,
		clientCtx: context.Background,
		genInvoiceReq: func(int64) (*lnrpc.Invoice, error) {
			return nil, nil
		},
		invoiceStates: make(
			map[lntypes.Hash]lnrpc.Invoice_InvoiceState,
		),
		quit:         make(chan struct{}),
		invoicesMtx:  invoicesMtx,
		invoicesCond: sync.NewCond(invoicesMtx),
		errChan:      make(chan error),
		strictVerify: false,
		onSettled: func(hash lntypes.Hash) {
			mu.Lock()
			settled = append(settled, hash)
			mu.Unlock()
		},
		settlementQueue: newSettlementQueue(),
	}

	err := c.Start()
	require.NoError(t, err)

	// Historical settled invoices should be reconciled asynchronously
	// through the queue.
	require.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()

		return len(settled) == 1 && settled[0] == hash
	}, time.Second, 10*time.Millisecond)

	mockClient.stop()
	c.Stop()
}

func TestSettlementQueueDrainOnStop(t *testing.T) {
	t.Parallel()

	var (
		mu      sync.Mutex
		settled []lntypes.Hash
	)

	// Create a challenger with a settlement callback.
	mockClient := &mockInvoiceClient{
		updateChan: make(chan *lnrpc.Invoice),
		errChan:    make(chan error, 1),
		quit:       make(chan struct{}),
	}
	genInvoiceReq := func(price int64) (*lnrpc.Invoice, error) {
		return newInvoice(lntypes.ZeroHash, 99, lnrpc.Invoice_OPEN),
			nil
	}
	invoicesMtx := &sync.Mutex{}
	c := &LndChallenger{
		client:        mockClient,
		batchSize:     1,
		clientCtx:     context.Background,
		genInvoiceReq: genInvoiceReq,
		invoiceStates: make(
			map[lntypes.Hash]lnrpc.Invoice_InvoiceState,
		),
		quit:         make(chan struct{}),
		invoicesMtx:  invoicesMtx,
		invoicesCond: sync.NewCond(invoicesMtx),
		errChan:      make(chan error),
		strictVerify: false,
		onSettled: func(hash lntypes.Hash) {
			mu.Lock()
			settled = append(settled, hash)
			mu.Unlock()
		},
		settlementQueue: newSettlementQueue(),
	}

	err := c.Start()
	require.NoError(t, err)

	// Send one settlement and wait for it.
	hash := lntypes.Hash{42}
	mockClient.updateChan <- newInvoice(
		hash, 1, lnrpc.Invoice_SETTLED,
	)

	require.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return len(settled) == 1
	}, time.Second, 10*time.Millisecond)

	// Stop should drain any remaining items.
	mockClient.stop()
	c.Stop()

	mu.Lock()
	require.GreaterOrEqual(t, len(settled), 1)
	mu.Unlock()
}

// untrackedInvoiceClient mints invoices but cannot be asked about them
// afterwards, which is the shape of every gateway-backed client. It counts the
// calls it should never see so a test can prove they did not happen, rather
// than only proving that startup did not fail.
type untrackedInvoiceClient struct {
	listCalls      int
	subscribeCalls int
}

var _ InvoiceClient = (*untrackedInvoiceClient)(nil)
var _ InvoiceTracker = (*untrackedInvoiceClient)(nil)

func (u *untrackedInvoiceClient) TracksInvoices() bool {
	return false
}

func (u *untrackedInvoiceClient) ListInvoices(_ context.Context,
	_ *lnrpc.ListInvoiceRequest,
	_ ...grpc.CallOption) (*lnrpc.ListInvoiceResponse, error) {

	u.listCalls++

	return nil, fmt.Errorf("listing invoices is not supported")
}

func (u *untrackedInvoiceClient) SubscribeInvoices(_ context.Context,
	_ *lnrpc.InvoiceSubscription, _ ...grpc.CallOption) (
	lnrpc.Lightning_SubscribeInvoicesClient, error) {

	u.subscribeCalls++

	return nil, fmt.Errorf("subscribing to invoices is not supported")
}

func (u *untrackedInvoiceClient) AddInvoice(_ context.Context,
	_ *lnrpc.Invoice, _ ...grpc.CallOption) (*lnrpc.AddInvoiceResponse,
	error) {

	return &lnrpc.AddInvoiceResponse{
		RHash:          lntypes.ZeroHash[:],
		PaymentRequest: "foo",
	}, nil
}

// TestUntrackedClientWithSettlementCallback covers the combination that used
// to take the whole proxy down on startup: an operator turns on the admin
// dashboard, which asks for a settlement callback without knowing what is
// minting the invoices, while the authenticator is a backend that cannot
// enumerate them. The callback has to be dropped, not honoured, because the
// only way to honour it is to call methods this client can only fail.
func TestUntrackedClientWithSettlementCallback(t *testing.T) {
	t.Parallel()

	client := &untrackedInvoiceClient{}
	genInvoiceReq := func(int64) (*lnrpc.Invoice, error) {
		return &lnrpc.Invoice{Value: 99}, nil
	}

	var settled []lntypes.Hash
	c, err := NewLndChallenger(
		client, 10, genInvoiceReq, context.Background,
		make(chan error), false,
		WithSettlementCallback(func(hash lntypes.Hash) {
			settled = append(settled, hash)
		}),
	)
	require.NoError(t, err)
	defer c.Stop()

	// Neither of the invoice tracking calls may have been attempted, and
	// no settlement queue should be left running to feed a callback that
	// can never fire.
	require.Zero(t, client.listCalls)
	require.Zero(t, client.subscribeCalls)
	require.Nil(t, c.onSettled)
	require.Nil(t, c.settlementQueue)
	require.Empty(t, settled)

	// Minting still works, which is the one thing this backend is for.
	_, _, err = c.NewChallenge(99)
	require.NoError(t, err)
}

// TestUntrackedClientRefusesStrictVerify checks that the tracking capability
// is not quietly downgraded. Strict verification means a token is honoured
// only once its invoice has been seen to settle, so skipping the tracking
// while leaving the flag on would honour tokens for invoices nobody paid.
func TestUntrackedClientRefusesStrictVerify(t *testing.T) {
	t.Parallel()

	_, err := NewLndChallenger(
		&untrackedInvoiceClient{}, 10,
		func(int64) (*lnrpc.Invoice, error) {
			return &lnrpc.Invoice{Value: 99}, nil
		}, context.Background, make(chan error), true,
	)
	require.ErrorContains(t, err, "strict verification")
}

// TestTrackingClientKeepsSettlementCallback is the other side of the same
// switch: a client that says nothing about the capability is taken to have it,
// so the ordinary lnd path is untouched by any of this.
func TestTrackingClientKeepsSettlementCallback(t *testing.T) {
	t.Parallel()

	hash := lntypes.Hash{7, 7, 7}
	mockClient := &mockInvoiceClient{
		invoices: []*lnrpc.Invoice{
			newInvoice(hash, 42, lnrpc.Invoice_SETTLED),
		},
		updateChan: make(chan *lnrpc.Invoice),
		errChan:    make(chan error, 1),
		quit:       make(chan struct{}),
	}

	var (
		mu      sync.Mutex
		settled []lntypes.Hash
	)

	c, err := NewLndChallenger(
		mockClient, 10, func(int64) (*lnrpc.Invoice, error) {
			return &lnrpc.Invoice{Value: 99}, nil
		}, context.Background, make(chan error), false,
		WithSettlementCallback(func(hash lntypes.Hash) {
			mu.Lock()
			settled = append(settled, hash)
			mu.Unlock()
		}),
	)
	require.NoError(t, err)

	require.NotNil(t, c.onSettled)
	require.NotNil(t, c.settlementQueue)

	require.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()

		return len(settled) == 1 && settled[0] == hash
	}, time.Second, 10*time.Millisecond)

	mockClient.stop()
	c.Stop()
}
